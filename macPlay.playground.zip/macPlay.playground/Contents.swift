//: Playground - noun: a place where people can play

import Cocoa

func getSerial() -> String?  {//Получить серийный номер mac-компьютера
    let platformExpert = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOPlatformExpertDevice") )
    
    guard platformExpert > 0 else {
        return nil
    }
    
    guard let serialNumber = (IORegistryEntryCreateCFProperty(platformExpert, kIOPlatformSerialNumberKey as CFString, kCFAllocatorDefault, 0).takeUnretainedValue() as? String)?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) else {
        return nil
    }
    
    
    IOObjectRelease(platformExpert)
    
    return serialNumber
}

func getSystemUUID() -> String? {//Получить SystemUUID для устройства Apple
    let dev = IOServiceMatching("IOPlatformExpertDevice")
    let platformExpert: io_service_t = IOServiceGetMatchingService(kIOMasterPortDefault, dev)
    let serialNumberAsCFString = IORegistryEntryCreateCFProperty(platformExpert, kIOPlatformUUIDKey as CFString, kCFAllocatorDefault, 0)
    IOObjectRelease(platformExpert)
    let ser: CFTypeRef = serialNumberAsCFString!.takeUnretainedValue()
    if let result = ser as? String {
        return result
    }
    return nil
}

print("your mac serial is \(getSerial() ?? "not found")")
print("Your system UUID is \(getSystemUUID() ?? "not found")")


